# 早期22段原创基础示意视频

本包包含K01-a至K11-b共22段静音MP4，每段8秒。它们是早期独立基础教学示意，不能视为当前188个问题页的视频版，也不是原作者视频的复制。

当前作品集：https://fsy132.github.io/
当前13模块、188问题页：https://fsy132.github.io/learning/
当前离线动画：https://fsy132.github.io/downloads/offline-learning.html
实际阅读范围：https://fsy132.github.io/learning/coverage.html

已完成16条原视频的全时段抽样与关键帧细读、1篇长文阅读；不是连续逐帧观看，74条图文尚未逐篇整理。当前版保留来源和适用条件修正。请优先使用当前网页课程。
